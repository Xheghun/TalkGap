package com.xheghun.vidit.models;

public class GalleryMedia {
    private String path;

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }
}
