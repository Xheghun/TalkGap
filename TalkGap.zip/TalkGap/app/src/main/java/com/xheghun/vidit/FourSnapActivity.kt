package com.xheghun.vidit


import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.Environment
import android.os.PersistableBundle
import android.util.Log
import android.util.Rational
import android.util.Size
import androidx.fragment.app.Fragment
import android.view.TextureView
import android.view.View
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton


import com.xheghun.vidit.adapter.ImageFrameAdapter
import com.xheghun.vidit.models.ImageData
import kotlinx.android.synthetic.main.fragment_four_snaps.*

import java.io.File
import java.io.FileInputStream
import java.lang.Exception
import java.util.ArrayList


/**
 * A simple [Fragment] subclass.
 */
val permissions = arrayOf(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE)

class FourSnapActivity : AppCompatActivity() {

    private val filename = "test.png"
    private val sd = Environment.getExternalStorageDirectory()
    private val dest = File(sd, filename)
    private var lensFacing = CameraX.LensFacing.BACK
    private var imageCapture: ImageCapture? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_four_snaps)

        val snapButton: FloatingActionButton = findViewById(R.id.snap_btn)
        val flashToggle: ImageButton = findViewById(R.id.flash_toggle_btn)
        val switchCamButton: ImageButton = findViewById(R.id.switch_cam_btn)
        bindCamera()

        val images = ArrayList<ImageData>()
        snapButton.setOnClickListener{
            imageCapture?.takePicture(dest,
                    object : ImageCapture.OnImageSavedListener {
                        override fun onError(error: ImageCapture.UseCaseError,
                                             message: String, exc: Throwable?) {
                            Log.e("Image", error.toString())
                        }
                        override fun onImageSaved(file: File) {
                            Log.v("Image", "Successfully saved image")
                            val image = ImageData()
                            image.imageBitmap = getBitmap(file.absolutePath)
                            images.add(image)
                            val layoutManager = LinearLayoutManager(this@FourSnapActivity)
                            layoutManager.orientation = RecyclerView.HORIZONTAL
                            image_frame_recycler_view.visibility = View.VISIBLE
                            image_frame_recycler_view.layoutManager = layoutManager
                            image_frame_recycler_view.adapter = ImageFrameAdapter(images,this@FourSnapActivity)
                            Toast.makeText(this@FourSnapActivity,"Photo Taken",Toast.LENGTH_SHORT).show()

                        }
                    }
            )
        }

        flashToggle.setOnClickListener {
            val flashMode = imageCapture?.flashMode
            if(flashMode == FlashMode.ON) {
                imageCapture?.flashMode = FlashMode.OFF
                Toast.makeText(this,"Flash Off",Toast.LENGTH_SHORT).show()
            }
            else{
                imageCapture?.flashMode = FlashMode.ON
                Toast.makeText(this,"Flash On",Toast.LENGTH_SHORT).show()
            }
        }

        switchCamButton.setOnClickListener {
            lensFacing = if (CameraX.LensFacing.FRONT == lensFacing) {
                CameraX.LensFacing.BACK
            } else {
                CameraX.LensFacing.FRONT
            }
            bindCamera()
            Toast.makeText(this,"Switching Cam",Toast.LENGTH_SHORT).show()

        }

        gallery_btn.setOnClickListener { startActivity(Intent(this,GalleryActivity::class.java)) }
    }

    private fun hasNoPermission() :Boolean {
        return ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this,
                Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED
    }

    private fun requestPermission() {
        // !! means cannot be null
        ActivityCompat.requestPermissions(this, permissions,0)
    }

    private fun bindCamera(){
        CameraX.unbindAll()

        // The view that displays the preview
        val textureView: TextureView = findViewById(R.id.texture_view)

        val aspectRatio = Rational(textureView.width,textureView.height)
        val screen = Size(textureView.width,textureView.height)

        // Preview config for the camera
        val previewConfig = PreviewConfig.Builder()
                .setLensFacing(lensFacing)
                .setTargetAspectRatio(aspectRatio)
                .setTargetResolution(screen)
                .build()

        val preview = Preview(previewConfig)



        // Handles the output data of the camera
        preview.setOnPreviewOutputUpdateListener { previewOutput ->
            // Displays the camera image in our preview view
            textureView.surfaceTexture = previewOutput.surfaceTexture
        }



        // Image capture config which controls the Flash and Lens
        val imageCaptureConfig = ImageCaptureConfig.Builder()
                .setTargetRotation(this.windowManager.defaultDisplay.rotation)
                .setLensFacing(lensFacing)
                .setFlashMode(FlashMode.ON)
                .build()

        imageCapture = ImageCapture(imageCaptureConfig)

        // Bind the camera to the lifecycle
        CameraX.bindToLifecycle(this as LifecycleOwner, imageCapture, preview)
    }

    override fun onStart() {
        super.onStart()
        //Check if request permissions
        if (hasNoPermission()) {
            requestPermission()
        }
    }

    private fun getBitmap(path: String): Bitmap? {
        try {
            var bitmap: Bitmap? = null
            val file = File(path)
            val options = BitmapFactory.Options()
            options.inPreferredConfig = Bitmap.Config.ARGB_8888

            bitmap = BitmapFactory.decodeStream(FileInputStream(file), null, options)


            return bitmap!!
        } catch (e: Exception) {

            return null
        }
    }
}
